// Kullanıcıdan işlem türünü ve iki sayı alıyoruz.
let islem = prompt("Matematiksel İşlem Seçin: toplama, çıkarma, çarpma, bölme");
let sayi1 = parseFloat(prompt("Birinci sayıyı girin:"));
let sayi2 = parseFloat(prompt("İkinci sayıyı girin:"));

// If-else yapısıyla işlemi gerçekleştiriyoruz.
let sonuc;

if (islem === "toplama") {
    sonuc = sayi1 + sayi2;
    console.log(`Sonuç (Toplama): ${sonuc}`);
} else if (islem === "çıkarma") {
    sonuc = sayi1 - sayi2;
    console.log(`Sonuç (Çıkarma): ${sonuc}`);
} else if (islem === "çarpma") {
    sonuc = sayi1 * sayi2;
    console.log(`Sonuç (Çarpma): ${sonuc}`);
} else if (islem === "bölme") {
    if (sayi2 !== 0) {
        sonuc = sayi1 / sayi2;
        console.log(`Sonuç (Bölme): ${sonuc}`);
    } else {
        console.error("Hata: Sıfıra bölme yapılamaz!");
    }
} else {
    console.error("Geçersiz işlem türü seçtiniz.");
}

// For döngüsü kullanarak 1'den 10'a kadar rakamları yazdırıyoruz.
console.log("1'den 10'a kadar olan rakamlar:");
for (let i = 1; i <= 10; i++) {
    console.log(i);
}
